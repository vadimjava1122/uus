#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${ROOT_DIR}"

if [[ -f "${ROOT_DIR}/.env" ]]; then
  # shellcheck disable=SC1091
  source "${ROOT_DIR}/.env"
else
  DISPLAY_NUM=99
fi

stop_pid_file() {
  local name="$1"
  local pid_file="${ROOT_DIR}/run/${name}.pid"
  if [[ -f "${pid_file}" ]]; then
    local pid
    pid="$(cat "${pid_file}" 2>/dev/null || true)"
    if [[ -n "${pid}" ]] && kill -0 "${pid}" 2>/dev/null; then
      echo "[stop] Остановка ${name} (PID ${pid})..."
      kill -TERM "${pid}" 2>/dev/null || true
      for _ in {1..10}; do
        if ! kill -0 "${pid}" 2>/dev/null; then
          break
        fi
        sleep 0.2
      done
      if kill -0 "${pid}" 2>/dev/null; then
        kill -KILL "${pid}" 2>/dev/null || true
      fi
    else
      echo "[stop] ${name}: процесс уже не активен"
    fi
    rm -f "${pid_file}"
  else
    echo "[stop] ${name}: PID-файл отсутствует"
  fi
}

echo "=================================================================="
echo " Остановка комплекта Xvfb + Chromium + Playwright MCP + noVNC"
echo "=================================================================="

stop_pid_file "mcp-session"
stop_pid_file "playwright-mcp"
stop_pid_file "test-page"
stop_pid_file "novnc"
stop_pid_file "x11vnc"
stop_pid_file "fluxbox"
stop_pid_file "xvfb"

rm -f "/tmp/.X${DISPLAY_NUM}-lock" "/tmp/.X11-unix/X${DISPLAY_NUM}" 2>/dev/null || true

echo "[stop] Все сервисы остановлены и временные сокеты очищены."
