#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${ROOT_DIR}"

echo "[install] Рабочая директория: ${ROOT_DIR}"

# 1. Создание рабочих папок
mkdir -p "${ROOT_DIR}/run" "${ROOT_DIR}/logs" "${ROOT_DIR}/output"
chmod 700 "${ROOT_DIR}/run"

# 2. Подготовка .env из env.example, если .env ещё нет
if [[ ! -f "${ROOT_DIR}/.env" ]]; then
  cp "${ROOT_DIR}/env.example" "${ROOT_DIR}/.env"
  echo "[install] Создан файл .env из шаблона env.example"
fi

# shellcheck disable=SC1091
source "${ROOT_DIR}/.env"

# 3. Установка системных пакетов Debian/Ubuntu
echo "[install] Проверка и установка системных пакетов (apt)..."
if command -v apt-get >/dev/null 2>&1; then
  SUDO=""
  if [[ "$(id -u)" -ne 0 ]]; then
    SUDO="sudo"
  fi
  ${SUDO} apt-get update -qq
  ${SUDO} DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    xvfb \
    x11vnc \
    novnc \
    python3-websockify \
    fluxbox \
    chromium \
    x11-utils \
    x11-xserver-utils \
    dbus-x11 \
    scrot \
    procps \
    curl \
    jq \
    fonts-liberation \
    fonts-dejavu-core
else
  echo "[install] Внимание: apt-get не найден. Убедитесь, что Xvfb, x11vnc, noVNC, Chromium установлены вручную."
fi

# 4. Установка Node.js-зависимостей (@playwright/mcp и @modelcontextprotocol/sdk)
echo "[install] Установка npm-пакетов (@playwright/mcp, @modelcontextprotocol/sdk)..."
if [[ ! -f "${ROOT_DIR}/package.json" ]]; then
  npm init -y >/dev/null
fi
npm install --no-audit --no-fund @playwright/mcp @modelcontextprotocol/sdk

# 5. Генерация случайного пароля для VNC (если ещё не создан)
VNC_PASS_PATH="${ROOT_DIR}/${VNC_PASS_FILE#./}"
VNC_PLAIN_PATH="${ROOT_DIR}/${VNC_PLAIN_FILE#./}"

if [[ ! -f "${VNC_PASS_PATH}" ]]; then
  RANDOM_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16 || true)"
  if [[ -z "${RANDOM_PASS}" ]]; then
    RANDOM_PASS="VncLocal$(date +%s)"
  fi
  printf "%s\n" "${RANDOM_PASS}" > "${VNC_PLAIN_PATH}"
  chmod 600 "${VNC_PLAIN_PATH}"
  x11vnc -storepasswd "${RANDOM_PASS}" "${VNC_PASS_PATH}" >/dev/null 2>&1
  chmod 600 "${VNC_PASS_PATH}"
  echo "[install] Сгенерирован локальный пароль VNC (сохранён в ${VNC_PASS_FILE} с правами 600)."
else
  echo "[install] Файл пароля VNC уже существует: ${VNC_PASS_FILE}"
fi

echo "[install] Установка успешно завершена!"
echo "  - Xvfb:           $(command -v Xvfb)"
echo "  - x11vnc:         $(command -v x11vnc)"
echo "  - websockify:     $(command -v websockify)"
echo "  - Chromium:       $(${CHROMIUM_BIN} --version)"
echo "  - Playwright MCP: $(npx --no-install playwright-mcp --version)"
