const { chromium } = require('/home/user/playwright-mcp-novnc-kit/vendor_modules/playwright-core');

(async () => {
  const timer = setTimeout(() => process.exit(0), 25000);
  try {
    const browser = await chromium.connectOverCDP('http://127.0.0.1:9222', { timeout: 5000 });
    const ctx = browser.contexts()[0];
    const page = await ctx.newPage();
    await page.bringToFront();
    await page.goto('https://news.ycombinator.com/', { waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.waitForTimeout(1500);
    const topItems = await page.evaluate(() => {
      const links = Array.from(document.querySelectorAll('.titleline > a')).slice(0, 5);
      return links.map((a, i) => `${i + 1}) ${a.innerText} (${a.href})`);
    });
    console.log('TOP_HN:\n' + topItems.join('\n'));
    // Smooth scroll down a bit so it's visible in VNC
    await page.mouse.wheel(0, 300);
    await page.waitForTimeout(1000);
  } catch (e) {
    console.error('ERR:', e.message);
  }
  clearTimeout(timer);
  process.exit(0);
})();
