#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const OUTPUT_DIR = path.join(ROOT_DIR, 'output');
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const MCP_URL = process.env.MCP_URL || 'http://127.0.0.1:8931/mcp';
const TEST_PAGE_URL = process.env.TEST_PAGE_URL || 'http://127.0.0.1:8088/';
const DISPLAY_ENV = process.env.DISPLAY || ':99';
const KEEP_OPEN = process.argv.includes('--keep-open');

function extractText(result) {
  if (!result || !Array.isArray(result.content)) return '';
  return result.content
    .filter((item) => item.type === 'text')
    .map((item) => item.text)
    .join('\n');
}

async function main() {
  console.log('==================================================================');
  console.log(' Проверка MCP-соединения с Playwright MCP и открытие тестовой страницы');
  console.log(` MCP Endpoint : ${MCP_URL}`);
  console.log(` Test Page URL: ${TEST_PAGE_URL}`);
  console.log(` Режим окна   : ${KEEP_OPEN ? 'Постоянно открытое окно (--keep-open)' : 'Разовая проверка'}`);
  console.log('==================================================================');

  const transport = new StreamableHTTPClientTransport(new URL(MCP_URL));
  const client = new Client(
    { name: KEEP_OPEN ? 'arena-mcp-keeper' : 'arena-mcp-verifier', version: '1.0.0' },
    { capabilities: {} }
  );

  await client.connect(transport);
  const serverVersion = client.getServerVersion();
  console.log('[1/6] Успешное подключение к MCP-серверу:', JSON.stringify(serverVersion));

  const toolsResponse = await client.listTools();
  const toolNames = toolsResponse.tools.map((t) => t.name);
  console.log(`[2/6] Получен список инструментов MCP (${toolNames.length}):`);
  console.log('      ' + toolNames.join(', '));

  // Открываем тестовую страницу через browser_navigate
  console.log(`[3/6] Вызов инструмента browser_navigate -> ${TEST_PAGE_URL}`);
  await client.callTool({
    name: 'browser_navigate',
    arguments: { url: TEST_PAGE_URL }
  });

  // Получаем первичный снимок для определения ref элементов
  const initialSnap = await client.callTool({
    name: 'browser_snapshot',
    arguments: {}
  });
  const initialSnapText = extractText(initialSnap);

  const inputMatch = initialSnapText.match(/textbox "Сообщение от MCP-клиента" \[ref=([^\]]+)\]/);
  const buttonMatch = initialSnapText.match(/button "Подтвердить MCP-тест" \[ref=([^\]]+)\]/);

  const inputTarget = inputMatch ? inputMatch[1] : '#mcp-input';
  const buttonTarget = buttonMatch ? buttonMatch[1] : '#mcp-submit-btn';

  console.log(`[4/6] Интерактивная проверка через MCP (target input=${inputTarget}, button=${buttonTarget})...`);
  await client.callTool({
    name: 'browser_type',
    arguments: {
      element: 'Поле ввода Сообщение от MCP-клиента',
      target: inputTarget,
      text: 'Привет из Playwright MCP! Экран Xvfb 1280x800 работает.'
    }
  });

  await client.callTool({
    name: 'browser_click',
    arguments: {
      element: 'Кнопка Подтвердить MCP-тест',
      target: buttonTarget
    }
  });

  // Получаем актуальный accessibility snapshot после клика
  console.log('[5/6] Запрос снимка состояния страницы (browser_snapshot) и скриншота (browser_take_screenshot)...');
  const snapResult = await client.callTool({
    name: 'browser_snapshot',
    arguments: {}
  });
  const snapText = extractText(snapResult);

  const screenshotRel = 'output/mcp-browser-screenshot.png';
  const screenshotRes = await client.callTool({
    name: 'browser_take_screenshot',
    arguments: {
      filename: screenshotRel,
      type: 'png',
      scale: 'css'
    }
  });
  if (screenshotRes.isError) {
    console.warn('Предупреждение browser_take_screenshot:', extractText(screenshotRes));
  }

  // Делаем полный снимок виртуального экрана Xvfb :99 (включая окно Chromium и Fluxbox)
  const xvfbShotPath = path.join(OUTPUT_DIR, 'xvfb-desktop-1280x800.png');
  try {
    execFileSync('scrot', ['--overwrite', xvfbShotPath], {
      env: { ...process.env, DISPLAY: DISPLAY_ENV }
    });
    console.log(`[6/6] Снимок виртуального экрана Xvfb (${DISPLAY_ENV}) сохранён: ${xvfbShotPath}`);
  } catch (err) {
    console.warn('[6/6] Не удалось выполнить scrot:', err.message);
  }

  const report = {
    verifiedAt: new Date().toISOString(),
    mcpEndpoint: MCP_URL,
    testPageUrl: TEST_PAGE_URL,
    display: DISPLAY_ENV,
    serverInfo: serverVersion,
    toolCount: toolNames.length,
    tools: toolNames,
    artifacts: {
      browserScreenshot: path.join(ROOT_DIR, screenshotRel),
      xvfbDesktopScreenshot: xvfbShotPath
    },
    pageSnapshotExcerpt: snapText.slice(0, 3000)
  };

  const reportPath = path.join(OUTPUT_DIR, 'mcp-verification-report.json');
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2), 'utf8');
  console.log(`Отчёт проверки сохранён: ${reportPath}`);

  if (KEEP_OPEN) {
    console.log('Окно Chromium остаётся открытым на DISPLAY=' + DISPLAY_ENV + ' (удерживается активная MCP-сессия)...');
    const shutdown = async () => {
      await client.close().catch(() => {});
      process.exit(0);
    };
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
    setInterval(() => {}, 60_000);
  } else {
    await client.close();
  }
}

main().catch((err) => {
  console.error('ОШИБКА проверки MCP:', err);
  process.exit(1);
});
