#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
mkdir -p run logs output profiles/browser1 profiles/element

echo "[1/6] Checking system packages and 1 GB swap..."
if ! command -v Xvfb >/dev/null 2>&1 || ! command -v x11vnc >/dev/null 2>&1 || ! command -v chromium >/dev/null 2>&1; then
  bash "$ROOT_DIR/scripts/install.sh"
fi

if ! /sbin/swapon --show | grep -q '/swapfile'; then
  sudo dd if=/dev/zero of=/swapfile bs=1M count=1024 status=none || true
  sudo chmod 600 /swapfile || true
  sudo /sbin/mkswap /swapfile >/dev/null 2>&1 || true
  sudo /sbin/swapon /swapfile >/dev/null 2>&1 || true
fi

if [ ! -f run/vnc.pass ]; then
  PASS="${VNC_PASSWORD:-lSuk4iUrv0vnMpS3}"
  printf "%s\n" "$PASS" > run/vnc.password.txt
  chmod 600 run/vnc.password.txt
  x11vnc -storepasswd "$PASS" run/vnc.pass >/dev/null 2>&1
  chmod 600 run/vnc.pass
fi

echo "[2/6] Cleaning Chromium Component Updater caches to keep workspace < 128 MB..."
for P in "$ROOT_DIR/profiles/browser1" "$ROOT_DIR/profiles/element"; do
  rm -rf "$P/WasmTtsEngine" "$P/OnDeviceHeadSuggestModel" "$P/BrowserMetrics"* \
         "$P/ActorSafetyLists" "$P/CertificateRevocation" "$P/hyphen-data" \
         "$P/ZxcvbnData" "$P/segmentation_platform" "$P/Default/Code Cache" \
         "$P/Default/Cache" "$P/Default/GPUCache" "$P/Default/Dawn"* \
         "$P/Singleton"* 2>/dev/null || true
done

echo "[3/6] Starting Browser 1 stack on :99 (VNC :5900, CDP :9222, HTTP :8088)..."
if ! xdpyinfo -display :99 >/dev/null 2>&1; then
  nohup Xvfb :99 -screen 0 1280x800x24 -dpi 96 -ac -nolisten tcp +extension GLX +render -noreset > logs/xvfb-99.log 2>&1 &
  echo $! > run/xvfb.pid
  sleep 1
fi

if ! ss -tln | grep -q ':8088 '; then
  nohup python3 -m http.server 8088 --bind 127.0.0.1 --directory "$ROOT_DIR/test-page" > logs/test-http.log 2>&1 &
  echo $! > run/test-http.pid
fi

DISPLAY=:99 nohup fluxbox -display :99 > logs/fluxbox-99.log 2>&1 &
echo $! > run/fluxbox.pid

if ! ss -tln | grep -q ':5900 '; then
  nohup x11vnc -display :99 -rfbport 5900 -localhost -rfbauth "$ROOT_DIR/run/vnc.pass" \
    -forever -shared -threads -speeds lan -wait 10 -defer 10 -o "$ROOT_DIR/logs/x11vnc.log" > logs/x11vnc-stdout.log 2>&1 &
  echo $! > run/x11vnc.pid
fi

if ! ss -tln | grep -q ':9222 '; then
  DISPLAY=:99 nohup /usr/bin/chromium \
    --no-sandbox \
    --disable-setuid-sandbox \
    --disable-dev-shm-usage \
    --disable-gpu \
    --disable-component-update \
    --renderer-process-limit=4 \
    --disk-cache-size=10485760 \
    --no-first-run \
    --no-default-browser-check \
    --user-data-dir="$ROOT_DIR/profiles/browser1" \
    --window-position=0,0 \
    --window-size=1280,800 \
    --remote-debugging-address=127.0.0.1 \
    --remote-debugging-port=9222 \
    "http://127.0.0.1:8088/index.html" > logs/chromium-1.log 2>&1 &
  echo $! > run/chromium-1.pid
fi

echo "[4/6] Starting Browser 2 stack on :98 (VNC :5901, CDP :9223, Element Matrix Client)..."
if ! xdpyinfo -display :98 >/dev/null 2>&1; then
  nohup Xvfb :98 -screen 0 1280x800x24 -ac -nolisten tcp -dpi 96 +extension RANDR > logs/xvfb-98.log 2>&1 &
  echo $! > run/xvfb-98.pid
  sleep 1
fi

DISPLAY=:98 nohup fluxbox -display :98 > logs/fluxbox-98.log 2>&1 &
echo $! > run/fluxbox-98.pid

if ! ss -tln | grep -q ':5901 '; then
  nohup x11vnc -display :98 -rfbport 5901 -localhost -rfbauth "$ROOT_DIR/run/vnc.pass" \
    -forever -shared -threads -speeds lan -wait 10 -defer 10 -o "$ROOT_DIR/logs/x11vnc-98.log" > logs/x11vnc-98-stdout.log 2>&1 &
  echo $! > run/x11vnc-98.pid
fi

if ! ss -tln | grep -q ':9223 '; then
  DISPLAY=:98 nohup /usr/bin/chromium \
    --no-sandbox \
    --disable-setuid-sandbox \
    --disable-dev-shm-usage \
    --disable-gpu \
    --disable-component-update \
    --renderer-process-limit=2 \
    --disk-cache-size=10485760 \
    --no-first-run \
    --no-default-browser-check \
    --user-data-dir="$ROOT_DIR/profiles/element" \
    --window-position=0,0 \
    --window-size=1280,800 \
    --remote-debugging-address=127.0.0.1 \
    --remote-debugging-port=9223 \
    "https://app.element.io/#/room/!UDC4TjKm2VSRrwYk2ip_UyTNhnzQBM9FnR2ehUX8VG4" > logs/chromium-element.log 2>&1 &
  echo $! > run/chromium-element.pid
fi

echo "[5/6] Installing/Starting cloudflared Quick Tunnel in /usr/local/bin/cloudflared..."
if [ ! -x /usr/local/bin/cloudflared ]; then
  sudo curl -fsSL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared
  sudo chmod +x /usr/local/bin/cloudflared
fi
ln -sf /usr/local/bin/cloudflared "$ROOT_DIR/run/cloudflared"

CF_URL=$(grep -oE 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' logs/cloudflared.log 2>/dev/null | head -n 1 || true)
if [ -z "$CF_URL" ] || ! curl -s -o /dev/null -w "%{http_code}" "${CF_URL}/vnc.html" | grep -q "200"; then
  if [ -f run/cloudflared.pid ]; then
    kill -TERM "$(cat run/cloudflared.pid)" 2>/dev/null || true
  fi
  nohup /usr/local/bin/cloudflared tunnel --no-autoupdate --url http://127.0.0.1:6080 > logs/cloudflared.log 2>&1 &
  echo $! > run/cloudflared.pid
  sleep 6
  CF_URL=$(grep -oE 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' logs/cloudflared.log 2>/dev/null | head -n 1 || true)
fi

echo "[6/6] Ready!"
echo "  VNC Password : $(cat run/vnc.password.txt)"
echo "  CF Tunnel    : ${CF_URL}/vnc.html?autoconnect=true&resize=scale"
