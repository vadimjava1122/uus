#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${ROOT_DIR}"

mkdir -p "${ROOT_DIR}/run" "${ROOT_DIR}/logs" "${ROOT_DIR}/output"
chmod 700 "${ROOT_DIR}/run"

if [[ ! -f "${ROOT_DIR}/.env" ]]; then
  cp "${ROOT_DIR}/env.example" "${ROOT_DIR}/.env"
fi

# shellcheck disable=SC1091
source "${ROOT_DIR}/.env"

export DISPLAY=":${DISPLAY_NUM}"
GEOMETRY="${SCREEN_WIDTH}x${SCREEN_HEIGHT}x${SCREEN_DEPTH}"
VIEWPORT="${SCREEN_WIDTH}x${SCREEN_HEIGHT}"
VNC_PASS_PATH="${ROOT_DIR}/${VNC_PASS_FILE#./}"
VNC_PLAIN_PATH="${ROOT_DIR}/${VNC_PLAIN_FILE#./}"

# Гарантируем наличие пароля VNC
if [[ ! -f "${VNC_PASS_PATH}" ]]; then
  RANDOM_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16 || true)"
  [[ -z "${RANDOM_PASS}" ]] && RANDOM_PASS="VncLocal$(date +%s)"
  printf "%s\n" "${RANDOM_PASS}" > "${VNC_PLAIN_PATH}"
  chmod 600 "${VNC_PLAIN_PATH}"
  x11vnc -storepasswd "${RANDOM_PASS}" "${VNC_PASS_PATH}" >/dev/null 2>&1
  chmod 600 "${VNC_PASS_PATH}"
fi

is_pid_running() {
  local pid_file="$1"
  if [[ -f "${pid_file}" ]]; then
    local pid
    pid="$(cat "${pid_file}" 2>/dev/null || true)"
    if [[ -n "${pid}" ]] && kill -0 "${pid}" 2>/dev/null; then
      return 0
    fi
  fi
  return 1
}

echo "=================================================================="
echo " Запуск комплекта Xvfb (${SCREEN_WIDTH}x${SCREEN_HEIGHT}) + Chromium + Playwright MCP + noVNC"
echo " Привязка сетевых интерфейсов: ${BIND_HOST} (без открытого доступа извне)"
echo "=================================================================="

# 1. Xvfb
if is_pid_running "${ROOT_DIR}/run/xvfb.pid"; then
  echo "[start] Xvfb уже запущен (PID $(cat "${ROOT_DIR}/run/xvfb.pid"))"
else
  rm -f "/tmp/.X${DISPLAY_NUM}-lock" "/tmp/.X11-unix/X${DISPLAY_NUM}" 2>/dev/null || true
  nohup Xvfb ":${DISPLAY_NUM}" \
    -screen 0 "${GEOMETRY}" \
    -dpi "${SCREEN_DPI}" \
    -ac \
    -nolisten tcp \
    +extension GLX \
    +render \
    -noreset \
    </dev/null >"${ROOT_DIR}/logs/xvfb.log" 2>&1 &
  echo $! > "${ROOT_DIR}/run/xvfb.pid"
  sleep 1
  if ! xdpyinfo -display ":${DISPLAY_NUM}" >/dev/null 2>&1; then
    echo "[start] ОШИБКА: Xvfb не запустился. Проверьте logs/xvfb.log" >&2
    exit 1
  fi
  echo "[start] Xvfb запущен на DISPLAY=:${DISPLAY_NUM} (${GEOMETRY}, -nolisten tcp)"
fi

# 2. Оконный менеджер Fluxbox
if is_pid_running "${ROOT_DIR}/run/fluxbox.pid"; then
  echo "[start] Fluxbox уже запущен (PID $(cat "${ROOT_DIR}/run/fluxbox.pid"))"
else
  nohup fluxbox -display ":${DISPLAY_NUM}" \
    </dev/null >"${ROOT_DIR}/logs/fluxbox.log" 2>&1 &
  echo $! > "${ROOT_DIR}/run/fluxbox.pid"
  sleep 1
  echo "[start] Оконный менеджер Fluxbox запущен на DISPLAY=:${DISPLAY_NUM}"
fi

# 3. x11vnc (локальный интерфейс + пароль)
if is_pid_running "${ROOT_DIR}/run/x11vnc.pid"; then
  echo "[start] x11vnc уже запущен (PID $(cat "${ROOT_DIR}/run/x11vnc.pid"))"
else
  VNC_LOCALHOST_FLAG="-localhost"
  if [[ "${BIND_HOST}" != "127.0.0.1" && "${BIND_HOST}" != "localhost" ]]; then
    VNC_LOCALHOST_FLAG="-listen ${BIND_HOST}"
  fi
  # shellcheck disable=SC2086
  nohup x11vnc \
    -display ":${DISPLAY_NUM}" \
    -rfbport "${VNC_PORT}" \
    ${VNC_LOCALHOST_FLAG} \
    -rfbauth "${VNC_PASS_PATH}" \
    -forever \
    -shared \
    -threads \
    -speeds lan \
    -wait 10 \
    -defer 10 \
    </dev/null >"${ROOT_DIR}/logs/x11vnc.log" 2>&1 &
  echo $! > "${ROOT_DIR}/run/x11vnc.pid"
  sleep 1
  echo "[start] x11vnc запущен на ${BIND_HOST}:${VNC_PORT} (защищён паролем из ${VNC_PASS_FILE})"
fi

# 4. noVNC / websockify
if is_pid_running "${ROOT_DIR}/run/novnc.pid"; then
  echo "[start] noVNC (websockify) уже запущен (PID $(cat "${ROOT_DIR}/run/novnc.pid"))"
else
  nohup websockify \
    --web /usr/share/novnc \
    "${BIND_HOST}:${NOVNC_PORT}" \
    "127.0.0.1:${VNC_PORT}" \
    </dev/null >"${ROOT_DIR}/logs/novnc.log" 2>&1 &
  echo $! > "${ROOT_DIR}/run/novnc.pid"
  sleep 1
  echo "[start] noVNC запущен: http://${BIND_HOST}:${NOVNC_PORT}/vnc.html?autoconnect=true&resize=scale"
fi

# 5. Локальный HTTP-сервер тестовой страницы
if is_pid_running "${ROOT_DIR}/run/test-page.pid"; then
  echo "[start] Сервер тестовой страницы уже запущен (PID $(cat "${ROOT_DIR}/run/test-page.pid"))"
else
  nohup python3 -m http.server "${TEST_PAGE_PORT}" \
    --bind "${BIND_HOST}" \
    --directory "${ROOT_DIR}/test-page" \
    </dev/null >"${ROOT_DIR}/logs/test-page.log" 2>&1 &
  echo $! > "${ROOT_DIR}/run/test-page.pid"
  sleep 1
  echo "[start] Тестовая страница доступна: http://${BIND_HOST}:${TEST_PAGE_PORT}/"
fi

# 6. Сервер Playwright MCP (Headed Chromium на DISPLAY=:99)
if is_pid_running "${ROOT_DIR}/run/playwright-mcp.pid"; then
  echo "[start] Playwright MCP уже запущен (PID $(cat "${ROOT_DIR}/run/playwright-mcp.pid"))"
else
  rm -rf /tmp/chromium-clean-profile
  mkdir -p /tmp/chromium-clean-profile
  nohup env DISPLAY=":${DISPLAY_NUM}" npx --no-install playwright-mcp \
    --config "${ROOT_DIR}/config/playwright-mcp.config.json" \
    --host "${BIND_HOST}" \
    --port "${MCP_PORT}" \
    --executable-path "${CHROMIUM_BIN}" \
    --no-sandbox \
    --shared-browser-context \
    --viewport-size "${VIEWPORT}" \
    --idle-timeout 0 \
    --output-dir "${ROOT_DIR}/output" \
    </dev/null >"${ROOT_DIR}/logs/playwright-mcp.log" 2>&1 &
  echo $! > "${ROOT_DIR}/run/playwright-mcp.pid"
  sleep 2
  echo "[start] Playwright MCP сервер запущен: http://${BIND_HOST}:${MCP_PORT}/mcp"
fi

# 7. Открытие окна Chromium через MCP и удержание активной сессии на экране :99
if is_pid_running "${ROOT_DIR}/run/mcp-session.pid"; then
  echo "[start] Активная MCP-сессия браузера уже запущена (PID $(cat "${ROOT_DIR}/run/mcp-session.pid"))"
else
  nohup env DISPLAY=":${DISPLAY_NUM}" node "${ROOT_DIR}/scripts/verify-mcp.mjs" --keep-open \
    </dev/null >"${ROOT_DIR}/logs/mcp-session.log" 2>&1 &
  echo $! > "${ROOT_DIR}/run/mcp-session.pid"
  sleep 3
  echo "[start] Окно Chromium открыто на DISPLAY=:${DISPLAY_NUM} с тестовой страницей"
fi

echo "=================================================================="
echo " Все компоненты успешно запущены!"
echo " Проверить статус: ./scripts/status.sh"
echo "=================================================================="
