#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${ROOT_DIR}"

if [[ -f "${ROOT_DIR}/.env" ]]; then
  # shellcheck disable=SC1091
  source "${ROOT_DIR}/.env"
else
  # shellcheck disable=SC1091
  source "${ROOT_DIR}/env.example"
fi

check_service() {
  local label="$1"
  local pid_file="${ROOT_DIR}/run/${2}.pid"
  if [[ -f "${pid_file}" ]]; then
    local pid
    pid="$(cat "${pid_file}" 2>/dev/null || true)"
    if [[ -n "${pid}" ]] && kill -0 "${pid}" 2>/dev/null; then
      printf "  [RUNNING] %-24s PID=%s\n" "${label}" "${pid}"
      return 0
    fi
  fi
  printf "  [STOPPED] %-24s\n" "${label}"
  return 1
}

echo "=== 1. Статус процессов ==="
check_service "Xvfb (:${DISPLAY_NUM})" "xvfb" || true
check_service "Fluxbox WM" "fluxbox" || true
check_service "x11vnc (:${VNC_PORT})" "x11vnc" || true
check_service "noVNC (:${NOVNC_PORT})" "novnc" || true
check_service "Test Page (:${TEST_PAGE_PORT})" "test-page" || true
check_service "Playwright MCP (:${MCP_PORT})" "playwright-mcp" || true
check_service "Browser Session (MCP)" "mcp-session" || true

echo ""
echo "=== 2. Проверка виртуального экрана Xvfb (:${DISPLAY_NUM}) и окон Chromium ==="
if xdpyinfo -display ":${DISPLAY_NUM}" >/dev/null 2>&1; then
  xdpyinfo -display ":${DISPLAY_NUM}" | grep -E "dimensions:|depths" | sed 's/^/  /'
  echo "  Открытые окна X11:"
  xwininfo -root -tree -display ":${DISPLAY_NUM}" 2>/dev/null | grep -iE "chromium| тестовый стенд" | sed 's/^/    /' || true
else
  echo "  Экран :${DISPLAY_NUM} недоступен"
fi

echo ""
echo "=== 3. Сетевые сокеты ==="
ss -tlnp 2>/dev/null | grep -E "(${VNC_PORT}|${NOVNC_PORT}|${MCP_PORT}|${TEST_PAGE_PORT}|Local Address)" | sed 's/^/  /' || true

echo ""
echo "=== 4. HTTP-проверка сервисов ==="
NOVNC_CODE="$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:${NOVNC_PORT}/vnc.html" || echo "ERR")"
TESTPAGE_CODE="$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:${TEST_PAGE_PORT}/" || echo "ERR")"
echo "  noVNC UI (http://127.0.0.1:${NOVNC_PORT}/vnc.html): HTTP ${NOVNC_CODE}"
echo "  Test Page (http://127.0.0.1:${TEST_PAGE_PORT}/):    HTTP ${TESTPAGE_CODE}"
