#!/usr/bin/env bash
set -u

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

CYCLE_LABEL="${1:-Batch}"
MAX_TICKS="${2:-400}"

CF_URL=$(grep -oE 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' "$ROOT_DIR/logs/cloudflared.log" 2>/dev/null | head -n 1 || true)

for i in $(seq 1 "$MAX_TICKS"); do
  if [ $((i % 50)) -eq 0 ]; then
    for P in "$ROOT_DIR/profiles/browser1" "$ROOT_DIR/profiles/element"; do
      rm -rf "$P/WasmTtsEngine" "$P/OnDeviceHeadSuggestModel" "$P/BrowserMetrics"* \
             "$P/Default/Code Cache" "$P/Default/Cache" "$P/Default/GPUCache" 2>/dev/null || true
    done
    if [ -f "$ROOT_DIR/output/heartbeat.txt" ]; then
      tail -n 200 "$ROOT_DIR/output/heartbeat.txt" > "$ROOT_DIR/output/heartbeat.txt.tmp" && \
        mv "$ROOT_DIR/output/heartbeat.txt.tmp" "$ROOT_DIR/output/heartbeat.txt"
    fi
  fi

  UP=$(awk '{print $1}' /proc/uptime)
  MEM=$(free -m | awk '/Mem:/ {print $3"/"$2"MB"}')
  S1=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:6080/vnc.html)
  S2=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:6081/vnc.html)
  POLL=$(node "$ROOT_DIR/scripts/element-bot.cjs" poll)

  LINE="[${CYCLE_LABEL} | Tick ${i}/${MAX_TICKS}] $(date -u '+%H:%M:%S') | Uptime: ${UP}s | RAM: ${MEM} | VNC1:${S1} VNC2:${S2} | CF:${CF_URL}"
  echo "$LINE" | tee -a "$ROOT_DIR/output/heartbeat.txt"

  if echo "$POLL" | grep -q '"newIncoming":\[{'; then
    echo "=== INCOMING TASK FROM ELEMENT ==="
    echo "$POLL"
    exit 0
  fi

  sleep 3
done
