const path = require('path');
const fs = require('fs');
const pw = require(path.join('/home/user/playwright-mcp-novnc-kit/vendor_modules', 'playwright-core'));

const STATE_FILE = '/home/user/playwright-mcp-novnc-kit/output/element-seen.json';

async function main() {
  const mode = process.argv[2] || 'poll'; // 'poll' | 'send'
  const textToSend = process.argv.slice(3).join(' ');

  const browser = await pw.chromium.connectOverCDP('http://127.0.0.1:9223');
  const pages = browser.contexts()[0].pages();
  const page = pages.find(p => p.url().includes('element.io')) || pages[0];

  if (mode === 'send' && textToSend) {
    const composer = page.locator('[role="textbox"][contenteditable="true"], .mx_BasicMessageComposer_input').first();
    await composer.click();
    await page.keyboard.type(textToSend);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(800);
    console.log('SENT:', textToSend);
    process.exit(0);
  }

  const messages = await page.evaluate(() => {
    const tiles = Array.from(document.querySelectorAll('.mx_EventTile'));
    const out = [];
    let lastSender = '';
    for (let i = 0; i < tiles.length; i++) {
      const t = tiles[i];
      if (t.className.includes('_stateInfo_') || t.className.includes('_stateBubbleContainer_') || t.className.includes('_stateEncryptionFailure_')) {
        continue;
      }
      const senderEl = t.querySelector('.mx_DisambiguatedProfile_displayName');
      if (senderEl && senderEl.textContent.trim()) {
        lastSender = senderEl.textContent.trim();
      }
      const isOwn = t.className.includes('_stateOwnEvent_');
      const bodySlot = t.querySelector('[data-testid="event-tile-slot-body"]');
      const body = bodySlot ? bodySlot.innerText.trim() : '';
      if (body) {
        out.push({ index: i, sender: isOwn ? 'димас' : (lastSender || 'vipfan'), isOwn, body });
      }
    }
    return out;
  });

  let seen = [];
  if (fs.existsSync(STATE_FILE)) {
    try { seen = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch {}
  }

  const incoming = messages.filter(m => !m.isOwn);
  const newIncoming = incoming.filter(m => !seen.includes(`${m.index}:${m.body}`));

  if (newIncoming.length > 0) {
    for (const m of incoming) {
      const key = `${m.index}:${m.body}`;
      if (!seen.includes(key)) seen.push(key);
    }
    fs.writeFileSync(STATE_FILE, JSON.stringify(seen, null, 2));
  }

  console.log(JSON.stringify({ totalMessages: messages.length, newIncoming, recent: messages.slice(-5) }));
  process.exit(0);
}

main().catch(err => {
  console.error('ERR:', err.message);
  process.exit(0);
});
