# Руководство для ИИ-ассистента: развёртывание стенда Dual-Browser + noVNC + Event-Polling Worker

Данный пакет (`playwright-mcp-novnc-kit`) предназначен для интерактивного тестирования веб-приложений пользователем через браузерный экран `noVNC` (1280×800) с синхронным получением задач из тестовой комнаты Matrix/Element (`!UDC4TjKm2VSRrwYk2ip_UyTNhnzQBM9FnR2ehUX8VG4`).

---

## 1. Архитектура стенда
1. **Экран 1 (`:99`, рабочий браузер пользователя):**
   - `Xvfb :99` (`1280x800x24`) + `Fluxbox`
   - `x11vnc` на `127.0.0.1:5900` (защищён паролем VNC `run/vnc.pass`)
   - `websockify / noVNC` на `0.0.0.0:6080` (запускается через `start_process` для Live Preview + проксируется через Cloudflare Quick Tunnel `cloudflared`)
   - `Chromium #1` с открытым локальным портом управления CDP `127.0.0.1:9222` (`--disable-component-update`, `--disk-cache-size=10485760`)
2. **Экран 2 (`:98`, клиент очереди задач Element/Matrix):**
   - `Xvfb :98` (`1280x800x24`) + `Fluxbox`
   - `x11vnc` на `127.0.0.1:5901` (защищён паролем VNC `run/vnc.pass`)
   - `websockify / noVNC` на `0.0.0.0:6081` (запускается через `start_process`)
   - `Chromium #2` с открытым портом CDP `127.0.0.1:9223`, открытый на комнате `https://app.element.io/#/room/!UDC4TjKm2VSRrwYk2ip_UyTNhnzQBM9FnR2ehUX8VG4`
3. **Контроль бюджета диска (`< 128 МБ`) и ОЗУ (`1 ГБ Swap`):**
   - Бинарный файл `cloudflared` размещается в `/usr/local/bin/cloudflared`, чтобы не расходовать лимит снапшота `/home/user` (128 МБ).
   - Флаг `--disable-component-update` и периодическая очистка `WasmTtsEngine` / `Code Cache` удерживают размер `/home/user` в пределах ~55 МБ.

---

## 2. Шаг 1 — Запуск всех сервисов и регистрация Live Preview (Первое сообщение)
1. Выполни в `bash`:
   ```bash
   bash /home/user/playwright-mcp-novnc-kit/scripts/start-dual.sh
   ```
2. Запусти два фоновых процесса через инструмент `start_process`:
   - **Процесс 1 (`name: "noVNC 1280x800 (Браузер 1)"`):**
     `/usr/bin/websockify --web /usr/share/novnc 0.0.0.0:6080 127.0.0.1:5900`
   - **Процесс 2 (`name: "noVNC Element (Браузер 2)"`):**
     `/usr/bin/websockify --web /usr/share/novnc 0.0.0.0:6081 127.0.0.1:5901`
3. Заверши первый ответ, сообщив пользователю ссылку `trycloudflare.com` и пароль VNC (`lSuk4iUrv0vnMpS3`), чтобы в интерфейсе зафиксировались плашки Live Preview, и попроси пользователя отправить команду старта воркера (например, `«запускай воркер»` или `«таймер»`).

---

## 3. Шаг 2 — Цикл опроса очереди задач и мониторинга (Event-Polling Worker)
Когда пользователь просит запустить интерактивный мониторинг/опрос чата:
1. Запускай батчи опроса через `bash` с параметром `timeout: 1800` (30 минут):
   ```bash
   bash /home/user/playwright-mcp-novnc-kit/scripts/poll-worker.sh "Batch-1" 400
   ```
2. Скрипт `poll-worker.sh` каждые 3 секунды проверяет HTTP-статус локальных сервисов (`6080`, `6081`) и вызывает `node scripts/element-bot.cjs poll`.
3. Как только в Element приходит новая задача от пользователя (`"newIncoming":[{...}]`), `poll-worker.sh` немедленно завершает работу (`exit 0`) и выводит текст задачи.
4. ИИ-ассистент выполняет задачу во втором окне/вкладке Браузера 1 (`http://127.0.0.1:9222`), отправляет отчёт в Element:
   ```bash
   node /home/user/playwright-mcp-novnc-kit/scripts/element-bot.cjs send "Отчёт о выполнении..."
   ```
   и переходит к следующему батчу `poll-worker.sh`, чередуя вызов `bash` с проверкой `get_process_output` или `read_file` (`output/heartbeat.txt`).
